<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateModelVarientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('model_varients', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('modelname');
            $table->integer('acinfo');
            $table->integer('seats');
            $table->integer('pushback');
            $table->integer('totalnos');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('model_varients');
    }
}
