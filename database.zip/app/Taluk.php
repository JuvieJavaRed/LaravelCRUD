<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Taluk extends Model
{
  // Timestamps
  public $timestamps = false;
}
